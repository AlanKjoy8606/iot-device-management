package com.example.iot.model;

public enum DeviceStatus {
    ONLINE, OFFLINE, ERROR
}
